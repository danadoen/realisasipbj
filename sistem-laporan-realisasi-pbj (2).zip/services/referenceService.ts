import { ReferencePaket, Modul } from '../types';
import { STORAGE_KEYS } from '../constants';

const INITIAL_DATA: Partial<ReferencePaket>[] = [
  { 
    kodeRUP: '39531761', 
    satuanKerja: 'Dinas Pertanian', 
    namaPaket: 'Honorarium Pejabat Pembuat Komitmen (PPK) Madu Trigona (Batulayar)', 
    metodePengadaan: 'Swakelola', 
    jenisPengadaan: 'Jasa Konsultansi', 
    sumberDana: 'APBD', 
    pagu: 850000, 
    modul: 'Swakelola' 
  },
];

export const getReferenceData = (): ReferencePaket[] => {
  const data = localStorage.getItem(STORAGE_KEYS.REFERENCE);
  if (!data) {
    const formatted = INITIAL_DATA.map(d => ({ 
      ...d, 
      id: crypto.randomUUID(),
      satuanKerja: d.satuanKerja || '',
      metodePengadaan: d.metodePengadaan || '',
      jenisPengadaan: d.jenisPengadaan || '',
      sumberDana: d.sumberDana || ''
    } as ReferencePaket));
    saveReferenceData(formatted);
    return formatted;
  }
  return JSON.parse(data);
};

export const saveReferenceData = (data: ReferencePaket[]) => {
  localStorage.setItem(STORAGE_KEYS.REFERENCE, JSON.stringify(data));
};

export const saveReferenceItem = (item: ReferencePaket) => {
  const data = getReferenceData();
  const index = data.findIndex(i => i.id === item.id);
  
  if (index !== -1) {
    data[index] = item;
  } else {
    data.push(item);
  }
  saveReferenceData(data);
};

export const findByRUP = (kode: string, modul?: Modul): ReferencePaket | undefined => {
  const data = getReferenceData();
  return data.find(item => item.kodeRUP === kode && (modul ? item.modul === modul : true));
};

export const deleteReferenceItem = (id: string) => {
  const data = getReferenceData();
  const filtered = data.filter(item => item.id !== id);
  saveReferenceData(filtered);
};

export const importReferenceData = (newData: ReferencePaket[]) => {
  const existing = getReferenceData();
  let added = 0;
  const combined = [...existing];
  
  newData.forEach(n => {
    const idx = combined.findIndex(e => e.kodeRUP === n.kodeRUP && e.modul === n.modul);
    if (idx === -1) {
      combined.push(n);
      added++;
    } else {
      combined[idx] = { ...n, id: combined[idx].id };
    }
  });
  
  saveReferenceData(combined);
  return added;
};