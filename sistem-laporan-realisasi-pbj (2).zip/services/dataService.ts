
import { Paket, AuditLog, Calculations, User } from '../types';

const API_BASE = '/api';

/**
 * Custom fetch with timeout to prevent infinite hanging
 */
const fetchWithTimeout = async (url: string, options: any = {}, timeout = 15000) => {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(id);
    return response;
  } catch (error: any) {
    clearTimeout(id);
    if (error.name === 'AbortError') {
      throw new Error("Koneksi terputus (Timeout). Server tidak merespon dalam batas waktu.");
    }
    throw error;
  }
};

/**
 * Safe JSON parsing to handle malformed strings like "null{...}" or extra characters
 */
const safeParseJson = async (response: Response) => {
  const text = await response.text();
  try {
    return JSON.parse(text.trim());
  } catch (e) {
    console.error("Gagal melakukan parse JSON dari respon:", text);
    throw new Error(`Format data tidak valid: ${text.substring(0, 50)}...`);
  }
};

const mapFromDb = (item: any): any => {
  if (!item) return null;
  return {
    ...item,
    kodeRUP: item.kode_rup,
    namaPaket: item.nama_paket,
    satuanKerja: item.satuan_kerja,
    metodePengadaan: item.metode_pengadaan,
    jenisPengadaan: item.jenis_pengadaan,
    sumberDana: item.sumber_dana,
    nomorKontrak: item.nomor_kontrak,
    nilaiKontrak: Number(item.nilai_kontrak || 0),
    realisasiKeuangan: Number(item.realisasi_keuangan || 0),
    fisikRencana: Number(item.fisik_rencana || 0),
    fisikRealisasi: Number(item.fisik_realisasi || 0),
    pagu: Number(item.pagu || 0),
    hps: Number(item.hps || 0),
    createdAt: item.created_at,
    updatedAt: item.updated_at,
    updatedBy: item.updated_by
  };
};

export const calculatePaketMetrics = (p: Partial<Paket>): Calculations => {
  const pagu = p.pagu || 0;
  const realisasi = p.realisasiKeuangan || 0;
  const fisikRencana = p.fisikRencana || 0;
  const fisikRealisasi = p.fisikRealisasi || 0;

  return {
    sisaKontrak: pagu - realisasi,
    keuanganPersen: pagu > 0 ? (realisasi / pagu) * 100 : 0,
    deviasiFisik: fisikRealisasi - fisikRencana
  };
};

// --- AUTH & USERS ---
export const warmUpApi = async (): Promise<{db: string}> => {
  try {
    const res = await fetchWithTimeout(`${API_BASE}/health`, {}, 12000);
    if (!res.ok) {
       console.error("Health check status error:", res.status);
       return { db: 'disconnected' };
    }
    return await safeParseJson(res);
  } catch (e) {
    console.error("Warm up API failed:", e);
    return { db: 'error' };
  }
};

export const loginApi = async (username: string, password: string): Promise<User> => {
  const res = await fetchWithTimeout(`${API_BASE}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  }, 30000); 
  
  if (!res.ok) {
    let message = "Login gagal.";
    try {
      const err = await safeParseJson(res);
      message = err.detail || message;
    } catch(e) {}
    throw new Error(message);
  }
  
  return await safeParseJson(res);
};

export const getUsersApi = async (): Promise<User[]> => {
  const res = await fetchWithTimeout(`${API_BASE}/users`);
  if (!res.ok) throw new Error("Gagal mengambil data user");
  return await safeParseJson(res);
};

export const saveUserApi = async (user: Partial<User>): Promise<void> => {
  const res = await fetchWithTimeout(`${API_BASE}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user)
  });
  if (!res.ok) throw new Error("Gagal menyimpan data user");
};

export const deleteUserApi = async (id: string): Promise<void> => {
  const res = await fetchWithTimeout(`${API_BASE}/users/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error("Gagal menghapus user");
};

// --- PAKETS ---
export const getPakets = async (): Promise<Paket[]> => {
  const res = await fetchWithTimeout(`${API_BASE}/pakets`);
  if (!res.ok) throw new Error("Gagal memuat paket dari database");
  const data = await safeParseJson(res);
  return data.map(mapFromDb);
};

export const savePaketToDb = async (paket: Partial<Paket>): Promise<Paket> => {
  const res = await fetchWithTimeout(`${API_BASE}/pakets`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(paket)
  });
  
  if (!res.ok) {
    const err = await safeParseJson(res);
    throw new Error(err.detail || "Gagal menyimpan paket");
  }
  
  const saved = await safeParseJson(res);
  return mapFromDb(saved);
};

export const deletePaketFromDb = async (id: string): Promise<void> => {
  const res = await fetchWithTimeout(`${API_BASE}/pakets/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error("Gagal menghapus paket dari server");
};

// --- AUDIT LOGS ---
export const getAuditLogs = async (): Promise<AuditLog[]> => {
  const res = await fetchWithTimeout(`${API_BASE}/logs`);
  if (!res.ok) return [];
  return await safeParseJson(res);
};

export const addAuditLog = async (user: User, action: AuditLog['action'], paket: Partial<Paket>, details: string): Promise<void> => {
  try {
    await fetchWithTimeout(`${API_BASE}/logs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: user.id,
        username: user.username,
        action,
        paketId: paket.id || 'SYSTEM',
        paketName: paket.namaPaket || '-',
        details
      })
    });
  } catch (e) {
    console.error("Gagal mencatat log", e);
  }
};
