
import { Paket, Modul } from '../types';
import { calculatePaketMetrics } from './dataService';

declare const ExcelJS: any;
declare const saveAs: any;

export const exportToExcel = async (pakets: Paket[], modul: Modul) => {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet(modul);

  // Formatting helpers
  const centerStyle = { alignment: { vertical: 'middle', horizontal: 'center' }, font: { bold: true } };
  const borderStyle = {
    top: { style: 'thin' },
    left: { style: 'thin' },
    bottom: { style: 'thin' },
    right: { style: 'thin' }
  };

  // Row 1: Title
  worksheet.mergeCells('A1:Y1');
  const titleCell = worksheet.getCell('A1');
  titleCell.value = `LAPORAN REALISASI KEUANGAN DAN FISIK (MODUL ${modul.toUpperCase()})`;
  titleCell.style = { ...centerStyle, font: { bold: true, size: 14 } };

  // Row 2: Note
  worksheet.mergeCells('A2:Y2');
  const noteCell = worksheet.getCell('A2');
  noteCell.value = `Update: ${new Date().toLocaleDateString('id-ID')}`;
  noteCell.alignment = { horizontal: 'center' };

  // Row 3 & 4: Headers
  const headers = [
    { cell: 'A3:A4', text: 'No' },
    { cell: 'B3:B4', text: 'Bidang' },
    { cell: 'C3:C4', text: 'Kode RUP' },
    { cell: 'D3:D4', text: 'Satuan Kerja' },
    { cell: 'E3:E4', text: 'Nama Paket Pekerjaan' },
    { cell: 'F3:F4', text: 'Pagu (Rp)' },
    { cell: 'G3:G4', text: 'HPS (Rp)' },
    { cell: 'H3:H4', text: 'Metode' },
    { cell: 'I3:I4', text: 'Jenis' },
    { cell: 'J3:J4', text: 'Sumber' },
    { cell: 'K3:N3', text: 'DATA KONTRAK' },
    { cell: 'O3:P3', text: 'KEUANGAN' },
    { cell: 'Q3:T3', text: 'FISIK' },
    { cell: 'U3:U4', text: 'SP2D' },
    { cell: 'V3:V4', text: 'Sisa Kontrak (Rp)' },
    { cell: 'W3:Y3', text: 'METADATA' }
  ];

  const subHeaders = [
    { col: 11, text: 'No. Kontrak' },
    { col: 12, text: 'Nilai (Rp)' },
    { col: 13, text: 'Tgl Mulai' },
    { col: 14, text: 'Tgl Selesai' },
    { col: 15, text: 'Realisasi (Rp)' },
    { col: 16, text: '%' },
    { col: 17, text: 'Rencana (%)' },
    { col: 18, text: 'Realisasi (%)' },
    { col: 19, text: 'Deviasi (%)' },
    { col: 20, text: 'Ket' },
    { col: 23, text: 'User' },
    { col: 24, text: 'Update' }
  ];

  headers.forEach(h => {
    worksheet.mergeCells(h.cell);
    const cell = worksheet.getCell(h.cell.split(':')[0]);
    cell.value = h.text;
    cell.style = centerStyle;
    cell.border = borderStyle;
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
  });

  subHeaders.forEach(sh => {
    const cell = worksheet.getRow(4).getCell(sh.col);
    cell.value = sh.text;
    cell.style = centerStyle;
    cell.border = borderStyle;
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E0E0' } };
  });

  // Data mapping
  pakets.forEach((p, idx) => {
    const metrics = calculatePaketMetrics(p);
    const rowData = [
      idx + 1,
      p.bidang,
      p.kodeRUP,
      p.satuanKerja,
      p.namaPaket,
      p.pagu,
      p.hps,
      p.metodePengadaan,
      p.jenisPengadaan,
      p.sumberDana,
      p.nomorKontrak,
      p.nilaiKontrak,
      '-', '-', // Dates placeholder
      p.realisasiKeuangan,
      metrics.keuanganPersen.toFixed(2),
      p.fisikRencana,
      p.fisikRealisasi,
      metrics.deviasiFisik.toFixed(2),
      '', // Ket
      p.sp2d,
      metrics.sisaKontrak,
      p.updatedBy,
      new Date(p.updatedAt).toLocaleDateString('id-ID')
    ];
    const row = worksheet.addRow(rowData);
    row.eachCell((cell: any) => {
      cell.border = borderStyle;
    });
  });

  worksheet.columns.forEach((column: any, i: number) => {
    if (i === 4) column.width = 45;
    else if (i === 3) column.width = 25;
    else column.width = 15;
  });

  const buffer = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([buffer]), `Laporan_PBJ_${modul}_${new Date().getTime()}.xlsx`);
};
