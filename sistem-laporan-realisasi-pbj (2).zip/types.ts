
export type Bidang = 'BUN' | 'BITNAKES' | 'UMUM' | 'PROGRAM' | 'KEUANGAN' | 'UPTPPAT' | 'PSP' | 'TPH/LUH';
export type Modul = 'Penyedia' | 'Swakelola';
export type UserRole = 'Admin' | 'User';

export interface User {
  id: string;
  username: string;
  role: UserRole;
  bidang: Bidang | 'ALL';
  password?: string;
}

export interface Paket {
  id: string;
  modul: Modul;
  bidang: Bidang;
  kodeRUP: string;
  namaPaket: string;
  satuanKerja: string;
  metodePengadaan: string;
  jenisPengadaan: string;
  sumberDana: string;
  pagu: number;
  hps: number;
  nomorKontrak: string;
  nilaiKontrak: number;
  realisasiKeuangan: number;
  fisikRencana: number;
  fisikRealisasi: number;
  sp2d: string;
  createdAt: string;
  updatedAt: string;
  updatedBy: string;
}

export interface ReferencePaket {
  id: string;
  kodeRUP: string;
  satuanKerja: string;
  namaPaket: string;
  metodePengadaan: string;
  jenisPengadaan: string;
  sumberDana: string;
  pagu: number;
  modul: Modul;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  username: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'IMPORT';
  paketId: string;
  paketName: string;
  details: string;
}

export interface Calculations {
  sisaKontrak: number;
  keuanganPersen: number;
  deviasiFisik: number;
}
