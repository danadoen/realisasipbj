import React, { useState } from 'react';
import { ReferencePaket, Modul } from '../types';
import { MODUL_OPTIONS } from '../constants';

interface ReferenceFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: ReferencePaket) => void;
  initialData?: ReferencePaket;
  activeModul: Modul;
}

const ReferenceForm: React.FC<ReferenceFormProps> = ({ onClose, onSave, initialData, activeModul }) => {
  const [formData, setFormData] = useState<ReferencePaket>(initialData || {
    id: crypto.randomUUID(),
    kodeRUP: '',
    namaPaket: '',
    satuanKerja: 'Dinas Pertanian',
    metodePengadaan: '',
    jenisPengadaan: '',
    sumberDana: 'APBD',
    pagu: 0,
    modul: activeModul
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? parseFloat(value) || 0 : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.kodeRUP || !formData.namaPaket) {
      alert('Kode RUP dan Nama Paket wajib diisi');
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[110] flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl p-10 transform animate-slide-up">
        <div className="flex items-center justify-between mb-8">
           <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
                 <i className={`fas fa-${initialData ? 'edit' : 'plus'} text-xl`}></i>
              </div>
              <div>
                 <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">{initialData ? 'Sunting Referensi' : 'Tambah Referensi'}</h3>
                 <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Master data RUP 2026</p>
              </div>
           </div>
           <button onClick={onClose} className="text-slate-300 hover:text-slate-600 transition-colors">
              <i className="fas fa-times text-2xl"></i>
           </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Kode RUP</label>
              <input 
                type="text" 
                name="kodeRUP"
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold"
                value={formData.kodeRUP}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Modul Kerja</label>
              <select 
                name="modul"
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold"
                value={formData.modul}
                onChange={handleChange}
              >
                {MODUL_OPTIONS.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Nama Paket Pekerjaan</label>
            <textarea 
              name="namaPaket"
              className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
              rows={3}
              value={formData.namaPaket}
              onChange={handleChange}
              required
            ></textarea>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Satuan Kerja</label>
              <input 
                type="text" 
                name="satuanKerja"
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold"
                value={formData.satuanKerja}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Nilai Pagu (Rp)</label>
              <input 
                type="number" 
                name="pagu"
                className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-black text-emerald-600"
                value={formData.pagu}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
             <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Metode</label>
              <input type="text" name="metodePengadaan" value={formData.metodePengadaan} onChange={handleChange} className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold" />
            </div>
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Jenis</label>
              <input type="text" name="jenisPengadaan" value={formData.jenisPengadaan} onChange={handleChange} className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold" />
            </div>
            <div className="space-y-1.5">
              <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest ml-1">Sumber</label>
              <input type="text" name="sumberDana" value={formData.sumberDana} onChange={handleChange} className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-bold" />
            </div>
          </div>

          <div className="flex space-x-4 mt-10">
            <button 
              type="button" 
              onClick={onClose} 
              className="flex-1 py-4 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 rounded-2xl transition-all"
            >
              Batal
            </button>
            <button 
              type="submit" 
              className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-xl shadow-slate-200 hover:bg-blue-600 transition-all active:scale-95"
            >
              Simpan Referensi
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReferenceForm;