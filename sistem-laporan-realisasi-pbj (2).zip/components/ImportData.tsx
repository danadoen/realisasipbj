
import React, { useState, useEffect } from 'react';
import { User, Modul, ReferencePaket } from '../types';
import { MODUL_OPTIONS } from '../constants';
import { importReferenceData, getReferenceData, deleteReferenceItem } from '../services/referenceService';
import { addAuditLog } from '../services/dataService';

interface ImportDataProps {
  user: User;
}

const ImportData: React.FC<ImportDataProps> = ({ user }) => {
  const [activeModul, setActiveModul] = useState<Modul>('Swakelola');
  const [csvText, setCsvText] = useState('');
  const [status, setStatus] = useState<{ type: 'success' | 'error', message: string } | null>(null);
  const [referenceList, setReferenceList] = useState<ReferencePaket[]>([]);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    setReferenceList(getReferenceData());
  }, []);

  const refreshList = () => {
    setReferenceList(getReferenceData());
  };

  const handleImport = () => {
    setStatus(null);
    if (!csvText.trim()) {
      setStatus({ type: 'error', message: 'Silakan tempelkan data dari Excel terlebih dahulu' });
      return;
    }

    try {
      const lines = csvText.trim().split('\n');
      const parsedData: ReferencePaket[] = lines.map((line, index) => {
        // Support both Tab (Excel Copy) and Comma
        const parts = line.split('\t').length > 1 ? line.split('\t') : line.split(',');
        
        // Expected 7 columns based on image:
        // 0: Kode RUP, 1: Satuan Kerja, 2: Nama Paket, 3: Metode Pengadaan, 4: Jenis Pengadaan, 5: Sumber Dana, 6: Nilai Pagu
        if (parts.length < 6) {
           throw new Error(`Baris ${index + 1} tidak valid. Pastikan data memiliki minimal 6-7 kolom sesuai format.`);
        }
        
        return {
          id: crypto.randomUUID(),
          kodeRUP: parts[0]?.trim() || '',
          satuanKerja: parts[1]?.trim() || '',
          namaPaket: parts[2]?.trim() || '',
          metodePengadaan: parts[3]?.trim() || '',
          jenisPengadaan: parts[4]?.trim() || '', // Optional/Middle
          sumberDana: parts[5]?.trim() || '',
          pagu: parseFloat(parts[6]?.replace(/[^\d.]/g, '') || parts[parts.length-1]?.replace(/[^\d.]/g, '') || '0') || 0,
          modul: activeModul
        };
      });

      const count = importReferenceData(parsedData);
      setStatus({ type: 'success', message: `Berhasil memproses ${parsedData.length} data. ${count} data baru ditambahkan/diperbarui.` });
      setCsvText('');
      refreshList();
      
      addAuditLog(user, 'IMPORT', { id: 'SYSTEM', namaPaket: `Bulk Import RUP - ${activeModul}` } as any, `Imported/Updated ${parsedData.length} records`);
    } catch (err: any) {
      setStatus({ type: 'error', message: err.message || 'Gagal memproses data. Periksa format kolom kembali.' });
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus item referensi ini?')) {
      deleteReferenceItem(id);
      refreshList();
    }
  };

  const filteredList = referenceList.filter(item => 
    item.modul === activeModul && (
      item.kodeRUP.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.namaPaket.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.satuanKerja.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12 animate-fade-in">
      {/* Import Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3 text-white">
            <div className="bg-blue-600 p-2 rounded-lg">
              <i className="fas fa-file-import"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold">Import Database RUP</h3>
              <p className="text-slate-400 text-xs mt-1">Gunakan format kolom yang sesuai dengan laporan RUP Pemerintah.</p>
            </div>
          </div>
          <div className="flex bg-slate-800 p-1 rounded-xl">
            {MODUL_OPTIONS.map(m => (
              <button
                key={m}
                onClick={() => setActiveModul(m)}
                className={`px-6 py-2 rounded-lg text-sm font-bold transition-all ${activeModul === m ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50' : 'text-slate-500 hover:text-slate-300'}`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
        
        <div className="p-8">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-bold text-slate-700">
                Tempel Data (Copy dari Excel)
              </label>
              <div className="flex items-center space-x-4 text-[10px] text-slate-400 font-mono uppercase">
                <span>1: Kode RUP</span>
                <span>2: SatKer</span>
                <span>3: Nama Paket</span>
                <span>4: Metode</span>
                <span>5: Jenis</span>
                <span>6: Sumber</span>
                <span>7: Pagu</span>
              </div>
            </div>
            <textarea
              className="w-full h-48 p-4 font-mono text-xs bg-slate-50 border-2 border-slate-100 rounded-xl outline-none focus:border-blue-500 focus:ring-4 focus:ring-blue-100 transition-all"
              placeholder="Contoh:&#10;39531761	Dinas Pertanian	Honorarium PPK	Swakelola	Jasa Konsultansi	APBD	850000"
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
            ></textarea>
          </div>

          {status && (
            <div className={`p-4 rounded-xl mb-6 flex items-center space-x-3 border-2 animate-bounce-in ${status.type === 'success' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-red-50 text-red-700 border-red-100'}`}>
              <i className={`fas fa-${status.type === 'success' ? 'check-circle' : 'exclamation-circle'} text-xl`}></i>
              <span className="text-sm font-medium">{status.message}</span>
            </div>
          )}

          <div className="flex justify-between items-center">
            <div className="text-xs text-slate-500 italic">
              <i className="fas fa-info-circle mr-1"></i>
              Data akan diupdate jika Kode RUP sudah ada di modul {activeModul}.
            </div>
            <button
              onClick={handleImport}
              className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-xl font-bold shadow-xl shadow-blue-100 transition-all flex items-center space-x-3 active:scale-95"
            >
              <i className="fas fa-cloud-upload-alt"></i>
              <span>Proses Data RUP</span>
            </button>
          </div>
        </div>
      </div>

      {/* List Card */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
              <i className="fas fa-database"></i>
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-lg">Database Referensi RUP</h3>
              <p className="text-slate-400 text-xs">Total {filteredList.length} data tersimpan untuk {activeModul}</p>
            </div>
          </div>
          
          <div className="relative w-full md:w-80">
            <i className="fas fa-search absolute left-3 top-3 text-slate-400"></i>
            <input 
              type="text" 
              placeholder="Cari dalam referensi..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto max-h-[600px]">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 sticky top-0 z-20">
              <tr className="border-b border-slate-200">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Kode RUP</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Satuan Kerja</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Nama Paket</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Metode / Jenis</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sumber / Pagu</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length > 0 ? filteredList.map(item => (
                <tr key={item.id} className="text-xs hover:bg-slate-50/80 transition-colors group">
                  <td className="px-6 py-4">
                    <span className="font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">{item.kodeRUP}</span>
                  </td>
                  <td className="px-6 py-4 text-slate-500 italic max-w-[150px] truncate">{item.satuanKerja}</td>
                  <td className="px-6 py-4 max-w-xs">
                    <div className="font-medium text-slate-800 line-clamp-2">{item.namaPaket}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <span className="bg-slate-100 px-2 py-0.5 rounded w-fit text-[9px] font-bold uppercase">{item.metodePengadaan}</span>
                      <span className="text-slate-400 italic text-[10px]">{item.jenisPengadaan}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-1">
                      <span className="font-bold text-emerald-600">{item.sumberDana}</span>
                      <span className="font-mono text-slate-700">Rp {item.pagu.toLocaleString('id-ID')}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => handleDelete(item.id)}
                      className="text-slate-300 hover:text-red-600 p-2 rounded-lg hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                      title="Hapus dari referensi"
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center opacity-30">
                      <i className="fas fa-search text-5xl mb-4"></i>
                      <p className="text-sm">Tidak ada data referensi yang cocok.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ImportData;
