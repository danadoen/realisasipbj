
import React, { useState, useEffect } from 'react';
import { User, Bidang } from '../types';
import { BIDANG_OPTIONS } from '../constants';
import { getUsersApi, saveUserApi, deleteUserApi } from '../services/dataService';

interface UserManagementProps {
  currentUser: User;
}

const UserManagement: React.FC<UserManagementProps> = ({ currentUser }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newUser, setNewUser] = useState<Partial<User>>({
    username: '',
    password: '',
    role: 'User',
    bidang: 'BUN'
  });

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await getUsersApi();
      setUsers(data);
    } catch (e) {
      console.error("Failed to load users", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUser.username || !newUser.password) {
      alert('Username dan Password wajib diisi');
      return;
    }
    
    try {
      await saveUserApi(newUser);
      await loadUsers();
      setIsAddOpen(false);
      setNewUser({ username: '', password: '', role: 'User', bidang: 'BUN' });
    } catch (err) {
      alert('Gagal menyimpan user ke database.');
    }
  };

  const handleDelete = async (id: string) => {
    if (id === '1' || users.find(u => u.id === id)?.username === 'admin') {
      alert('Akun admin utama tidak dapat dihapus');
      return;
    }
    if (window.confirm('Hapus pengguna ini?')) {
      try {
        await deleteUserApi(id);
        await loadUsers();
      } catch (err) {
        alert('Gagal menghapus user.');
      }
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Manajemen Otoritas</h3>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Kelola akun di database Supabase</p>
        </div>
        <button 
          onClick={() => setIsAddOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl flex items-center space-x-3 shadow-xl transition-all font-bold text-sm"
        >
          <i className="fas fa-user-plus"></i>
          <span>Tambah Pengguna</span>
        </button>
      </div>

      <div className="bg-white rounded-[2rem] shadow-xl border border-slate-100 overflow-hidden">
        {loading ? (
          <div className="p-20 text-center text-slate-400">Memuat data user...</div>
        ) : (
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Username</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Role</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Bidang</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-5 font-black text-slate-700">{u.username}</td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase ${u.role === 'Admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-8 py-5 font-bold text-blue-600 text-sm">{u.bidang}</td>
                  <td className="px-8 py-5 text-right">
                    <button 
                      onClick={() => handleDelete(u.id)}
                      className="text-slate-300 hover:text-red-600 p-2"
                      disabled={u.username === 'admin'}
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl p-8 animate-slide-up">
            <h3 className="text-xl font-black mb-6">Tambah Akun</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <input 
                type="text" placeholder="Username" 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold"
                value={newUser.username} onChange={e => setNewUser({...newUser, username: e.target.value})}
              />
              <input 
                type="password" placeholder="Password" 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold"
                value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})}
              />
              <select 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold"
                value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value as any})}
              >
                <option value="User">User</option>
                <option value="Admin">Admin</option>
              </select>
              <select 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold"
                value={newUser.bidang} onChange={e => setNewUser({...newUser, bidang: e.target.value as any})}
              >
                {BIDANG_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
              </select>
              <div className="flex space-x-4 pt-4">
                <button type="button" onClick={() => setIsAddOpen(false)} className="flex-1 py-4 font-bold text-slate-400">Batal</button>
                <button type="submit" className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-bold">Simpan</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
