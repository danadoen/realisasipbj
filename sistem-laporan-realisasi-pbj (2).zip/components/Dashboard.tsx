
import React, { useState, useEffect, useMemo } from 'react';
import { User, Paket, Modul, Bidang, AuditLog } from '../types';
import { BIDANG_OPTIONS, MODUL_OPTIONS } from '../constants';
import { getPakets, savePaketToDb, deletePaketFromDb, addAuditLog, getAuditLogs, calculatePaketMetrics } from '../services/dataService';
import { exportToExcel } from '../services/exportService';
import PaketForm from './PaketForm';
import UserManagement from './UserManagement';
import ImportData from './ImportData';
import ReferenceView from './ReferenceView';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

type ViewMode = 'TABLE' | 'LOGS' | 'USERS' | 'IMPORT' | 'REFERENCE';

const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const [pakets, setPakets] = useState<Paket[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [activeModul, setActiveModul] = useState<Modul>('Penyedia');
  const [filterBidang, setFilterBidang] = useState<Bidang | 'ALL'>(user.bidang);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedPaket, setSelectedPaket] = useState<Paket | undefined>(undefined);
  const [viewMode, setViewMode] = useState<ViewMode>('TABLE');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [paketsData, logsData] = await Promise.all([
        getPakets(),
        getAuditLogs()
      ]);
      setPakets(paketsData);
      setLogs(logsData);
    } catch (e) {
      console.error("Load data failed", e);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredPakets = useMemo(() => {
    return pakets.filter(p => {
      const matchModul = p.modul === activeModul;
      const matchBidang = filterBidang === 'ALL' || p.bidang === filterBidang;
      const matchSearch = (p.namaPaket || "").toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (p.kodeRUP || "").toLowerCase().includes(searchQuery.toLowerCase());
      return matchModul && matchBidang && matchSearch;
    });
  }, [pakets, activeModul, filterBidang, searchQuery]);

  const stats = useMemo(() => {
    const subset = filteredPakets;
    const totalPagu = subset.reduce((acc, curr) => acc + (curr.pagu || 0), 0);
    const totalRealisasi = subset.reduce((acc, curr) => acc + (curr.realisasiKeuangan || 0), 0);
    const avgFisik = subset.length > 0 ? subset.reduce((acc, curr) => acc + (curr.fisikRealisasi || 0), 0) / subset.length : 0;
    return { totalPagu, totalRealisasi, avgFisik, count: subset.length };
  }, [filteredPakets]);

  const handleSavePaket = async (formData: Partial<Paket>) => {
    try {
      const payload = {
        ...formData,
        id: selectedPaket?.id,
        modul: activeModul,
        updatedBy: user.username
      };
      
      const saved = await savePaketToDb(payload);
      await addAuditLog(user, selectedPaket ? 'UPDATE' : 'CREATE', saved, `${selectedPaket ? 'Update' : 'Tambah'} paket.`);
      
      await loadData();
      setIsFormOpen(false);
      setSelectedPaket(undefined);
    } catch (err: any) {
      alert(err.message || 'Gagal menyimpan data ke database.');
    }
  };

  const handleDeletePaket = async (id: string) => {
    if (window.confirm('Hapus paket ini secara permanen dari Supabase?')) {
      try {
        const pToDelete = pakets.find(p => p.id === id);
        await deletePaketFromDb(id);
        if (pToDelete) {
          await addAuditLog(user, 'DELETE', pToDelete, `Hapus paket: ${pToDelete.namaPaket}`);
        }
        setPakets(prev => prev.filter(p => p.id !== id));
      } catch (err: any) {
        alert(err.message || 'Gagal menghapus data.');
      }
    }
  };

  if (isLoading && viewMode === 'TABLE' && pakets.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-slate-100">
        <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="font-black text-slate-900 animate-pulse uppercase tracking-widest text-sm">Menghubungkan ke Supabase...</p>
      </div>
    );
  }

  return (
    <div className="flex bg-slate-100 min-h-screen">
      <aside className={`${isSidebarCollapsed ? 'lg:w-20' : 'lg:w-64'} fixed h-full bg-slate-900 text-slate-300 flex flex-col z-50 transition-all duration-300 shadow-2xl`}>
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg text-white shadow-lg">
              <i className="fas fa-chart-line"></i>
            </div>
            {!isSidebarCollapsed && <span className="font-black text-white text-lg tracking-tight">SIM PBJ</span>}
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          <SidebarLink icon="table" label="Dashboard Utama" active={viewMode === 'TABLE'} collapsed={isSidebarCollapsed} onClick={() => setViewMode('TABLE')} />
          <SidebarLink icon="history" label="Log Aktivitas" active={viewMode === 'LOGS'} collapsed={isSidebarCollapsed} onClick={() => setViewMode('LOGS')} />
          <SidebarLink icon="database" label="Master RUP" active={viewMode === 'REFERENCE'} collapsed={isSidebarCollapsed} onClick={() => setViewMode('REFERENCE')} />
          {user.role === 'Admin' && (
             <>
               <div className="pt-4 pb-2">
                 <p className="text-[10px] font-black text-slate-500 uppercase px-2 mb-2 tracking-widest">Admin Tools</p>
                 <SidebarLink icon="users" label="Kelola User" active={viewMode === 'USERS'} collapsed={isSidebarCollapsed} onClick={() => setViewMode('USERS')} />
                 <SidebarLink icon="cloud-upload-alt" label="Bulk Import" active={viewMode === 'IMPORT'} collapsed={isSidebarCollapsed} onClick={() => setViewMode('IMPORT')} />
               </div>
             </>
          )}

          <div className="pt-6 border-t border-slate-800">
            <p className="text-[10px] font-black text-slate-500 uppercase px-2 mb-2 tracking-widest">{isSidebarCollapsed ? 'MOD' : 'Tipe Modul'}</p>
            {MODUL_OPTIONS.map(m => (
              <button key={m} onClick={() => { setActiveModul(m); setViewMode('TABLE'); }} className={`w-full flex items-center px-4 py-3.5 rounded-2xl transition-all ${activeModul === m && viewMode === 'TABLE' ? 'bg-blue-600 text-white shadow-xl shadow-blue-900/40' : 'hover:bg-slate-800/50 text-slate-400'}`}>
                <i className={`fas fa-${m === 'Penyedia' ? 'truck' : 'user-cog'} w-5 mr-3`}></i>
                {!isSidebarCollapsed && <span className="text-sm font-bold">{m}</span>}
              </button>
            ))}
          </div>
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className={`flex items-center rounded-xl ${isSidebarCollapsed ? 'justify-center' : 'bg-slate-800/40 p-3'}`}>
            <div className="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center text-white font-bold shadow-inner">
              {user.username.charAt(0).toUpperCase()}
            </div>
            {!isSidebarCollapsed && (
              <div className="flex-1 ml-3 overflow-hidden">
                <p className="text-xs font-bold text-white truncate uppercase">{user.username}</p>
                <div className="flex items-center text-[9px]">
                   <span className="w-1.5 h-1.5 rounded-full mr-1 bg-emerald-500 animate-pulse"></span>
                   <span className="text-slate-500 uppercase font-black">Online</span>
                </div>
              </div>
            )}
            {!isSidebarCollapsed && (
              <button onClick={onLogout} className="text-slate-500 hover:text-red-400 p-2 transition-colors"><i className="fas fa-sign-out-alt"></i></button>
            )}
          </div>
        </div>
      </aside>

      <main className={`flex-1 ${isSidebarCollapsed ? 'lg:ml-20' : 'lg:ml-64'} p-8 transition-all duration-300`}>
        <header className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-4">
          <div>
            <h2 className="text-3xl font-black text-slate-900 uppercase tracking-tighter">
              {viewMode === 'TABLE' ? `MONITORING ${activeModul}` : viewMode.replace('_', ' ')}
            </h2>
            <div className="flex items-center space-x-2 text-xs font-black text-slate-400 mt-1 uppercase tracking-widest">
               <i className="fas fa-cloud text-emerald-500"></i>
               <span>SUPABASE POSTGRESQL ACTIVE</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
             {viewMode === 'TABLE' && (
               <>
                 <div className="relative">
                    <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input 
                      type="text" 
                      placeholder="Cari RUP / Paket..." 
                      className="pl-12 pr-6 py-3 bg-white border border-slate-200 rounded-2xl outline-none focus:ring-4 focus:ring-blue-100 focus:border-blue-500 transition-all font-bold text-sm w-64 shadow-sm"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                 </div>
                 <button onClick={() => exportToExcel(filteredPakets, activeModul)} className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-3 rounded-2xl flex items-center space-x-2 shadow-lg shadow-emerald-900/20 transition-all font-black text-xs uppercase tracking-widest active:scale-95">
                  <i className="fas fa-file-excel"></i>
                  <span>Export</span>
                </button>
                <button onClick={() => { setSelectedPaket(undefined); setIsFormOpen(true); }} className="bg-slate-900 hover:bg-blue-600 text-white px-6 py-3 rounded-2xl flex items-center space-x-2 shadow-xl shadow-slate-900/20 transition-all font-black text-xs uppercase tracking-widest active:scale-95">
                  <i className="fas fa-plus"></i>
                  <span>Entry Data</span>
                </button>
               </>
             )}
          </div>
        </header>

        {viewMode === 'TABLE' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
              <StatCard title="Total Paket" value={stats.count} icon="folder" color="blue" />
              <StatCard title="Pagu Anggaran" value={`Rp ${stats.totalPagu.toLocaleString('id-ID')}`} icon="wallet" color="indigo" />
              <StatCard title="Realisasi Keu" value={`Rp ${stats.totalRealisasi.toLocaleString('id-ID')}`} icon="money-bill-wave" color="emerald" />
              <StatCard title="Progres Fisik" value={`${stats.avgFisik.toFixed(1)}%`} icon="hard-hat" color="amber" />
            </div>

            <div className="bg-white rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.04)] border border-slate-100 overflow-hidden">
              <table className="w-full text-left">
                <thead className="bg-slate-50/50 border-b border-slate-100">
                  <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <th className="px-8 py-6">Paket & RUP</th>
                    <th className="px-8 py-6">Anggaran (Pagu/HPS)</th>
                    <th className="px-8 py-6">Realisasi Keuangan</th>
                    <th className="px-8 py-6">Fisik</th>
                    <th className="px-8 py-6 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredPakets.map(p => {
                    const metrics = calculatePaketMetrics(p);
                    return (
                      <tr key={p.id} className="hover:bg-blue-50/20 transition-all group">
                        <td className="px-8 py-6">
                          <div className="flex flex-col">
                            <span className="text-[9px] font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded-lg w-fit mb-2 border border-blue-100">{p.bidang}</span>
                            <span className="font-black text-slate-800 text-sm leading-tight tracking-tight">{p.namaPaket}</span>
                            <span className="text-[11px] text-slate-400 font-mono mt-1 font-bold">RUP ID: {p.kodeRUP}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="text-sm font-black text-slate-700 tracking-tighter">Rp {(p.pagu || 0).toLocaleString('id-ID')}</div>
                          <div className="text-[10px] text-slate-400 font-bold uppercase mt-1">HPS: Rp {(p.hps || 0).toLocaleString('id-ID')}</div>
                        </td>
                        <td className="px-8 py-6 min-w-[180px]">
                           <div className="flex justify-between text-[10px] font-black mb-1.5 uppercase tracking-tighter">
                              <span className="text-slate-400">Progres Keuangan</span>
                              <span className="text-blue-600">{metrics.keuanganPersen.toFixed(1)}%</span>
                           </div>
                           <div className="h-2 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                              <div className="h-full bg-gradient-to-r from-blue-500 to-indigo-600" style={{ width: `${Math.min(metrics.keuanganPersen, 100)}%` }}></div>
                           </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="text-sm font-black text-slate-800">{(p.fisikRealisasi || 0)}%</div>
                          <div className={`text-[10px] font-black mt-1 uppercase ${metrics.deviasiFisik >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                             DEV: {metrics.deviasiFisik.toFixed(1)}%
                          </div>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <div className="flex items-center justify-end space-x-2 lg:opacity-0 group-hover:opacity-100 transition-all">
                            <button onClick={() => { setSelectedPaket(p); setIsFormOpen(true); }} className="w-10 h-10 flex items-center justify-center text-blue-600 bg-white border border-slate-100 hover:bg-blue-600 hover:text-white rounded-xl transition-all shadow-md active:scale-90"><i className="fas fa-edit"></i></button>
                            <button onClick={() => handleDeletePaket(p.id)} className="w-10 h-10 flex items-center justify-center text-red-600 bg-white border border-slate-100 hover:bg-red-600 hover:text-white rounded-xl transition-all shadow-md active:scale-90"><i className="fas fa-trash-alt"></i></button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {filteredPakets.length === 0 && (
                <div className="p-32 text-center">
                   <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center mx-auto mb-6 text-slate-200 border-2 border-dashed border-slate-100">
                      <i className="fas fa-search text-4xl"></i>
                   </div>
                   <p className="text-slate-400 font-black uppercase text-xs tracking-[0.2em]">Belum ada data</p>
                </div>
              )}
            </div>
          </>
        )}

        {viewMode === 'LOGS' && (
          <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-50/50 border-b">
                <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                  <th className="px-8 py-6">Waktu</th>
                  <th className="px-8 py-6">User</th>
                  <th className="px-8 py-6">Aksi</th>
                  <th className="px-8 py-6">Detail</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-6 text-[11px] font-bold text-slate-500">{new Date(log.timestamp).toLocaleString('id-ID')}</td>
                    <td className="px-8 py-6 font-black text-slate-800 text-xs">{log.username}</td>
                    <td className="px-8 py-6">
                      <span className={`px-2 py-1 rounded-lg font-black uppercase text-[9px] border ${
                        log.action === 'CREATE' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                        log.action === 'UPDATE' ? 'bg-blue-50 text-blue-600 border-blue-100' :
                        'bg-red-50 text-red-600 border-red-100'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-xs font-bold text-slate-600">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {viewMode === 'USERS' && <UserManagement currentUser={user} />}
        {viewMode === 'IMPORT' && <ImportData user={user} />}
        {viewMode === 'REFERENCE' && <ReferenceView />}
      </main>

      {isFormOpen && (
        <PaketForm isOpen={isFormOpen} onClose={() => setIsFormOpen(false)} onSave={handleSavePaket} initialData={selectedPaket} user={user} />
      )}
    </div>
  );
};

const SidebarLink: React.FC<{ icon: string; label: string; active: boolean; collapsed: boolean; onClick: () => void }> = ({ icon, label, active, collapsed, onClick }) => (
  <button onClick={onClick} className={`w-full flex items-center px-4 py-3.5 rounded-2xl transition-all ${active ? 'bg-blue-600 text-white shadow-xl shadow-blue-900/40' : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'}`}>
    <i className={`fas fa-${icon} w-6 mr-3 text-lg`}></i>
    {!collapsed && <span className="text-sm font-bold tracking-tight">{label}</span>}
  </button>
);

const StatCard: React.FC<{ title: string; value: string | number; icon: string; color: string }> = ({ title, value, icon, color }) => (
  <div className="bg-white p-7 rounded-[2rem] border border-slate-100 flex items-center space-x-5 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group">
    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-xl bg-${color}-50 text-${color}-600 shadow-inner group-hover:scale-110 transition-transform duration-500`}>
      <i className={`fas fa-${icon}`}></i>
    </div>
    <div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{title}</p>
      <p className="text-lg font-black text-slate-900 tracking-tighter">{value}</p>
    </div>
  </div>
);

export default Dashboard;
