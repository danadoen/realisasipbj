
import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { loginApi, warmUpApi } from '../services/dataService';

interface AuthPageProps {
  onLogin: (user: User) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [dbStatus, setDbStatus] = useState<'warming' | 'connected' | 'error'>('warming');

  const checkStatus = async () => {
    setDbStatus('warming');
    try {
      const result = await warmUpApi();
      if (result && result.db === 'connected') {
        setDbStatus('connected');
      } else {
        setDbStatus('error');
      }
    } catch (e) {
      setDbStatus('error');
    }
  };

  useEffect(() => {
    checkStatus();
    const interval = setInterval(checkStatus, 45000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) return;
    
    setIsLoggingIn(true);
    setError('');
    
    try {
      const user = await loginApi(username, password);
      onLogin(user);
    } catch (err: any) {
      console.error("Login attempt failed:", err);
      // Even if health check failed, we still try login and show real backend error if login fails
      setError(err.message || "Sistem tidak merespon. Silakan coba beberapa saat lagi.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#0a0f1d] px-4 font-sans text-slate-200">
      <div className="w-full max-w-md bg-white rounded-[3.5rem] shadow-[0_30px_100px_rgba(0,0,0,0.6)] p-12 relative overflow-hidden border border-slate-200">
        <div className="absolute top-0 left-0 right-0 h-2.5 bg-blue-500"></div>
        
        <div className="text-center mb-10">
          <div className="w-24 h-24 mx-auto mb-6 rounded-3xl bg-blue-50 flex items-center justify-center text-4xl text-blue-600 shadow-2xl relative overflow-hidden">
            <i className={`fas fa-shield-alt ${isLoggingIn ? 'animate-pulse' : ''}`}></i>
            {isLoggingIn && (
               <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
            )}
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase leading-none">REALISASI PBJ</h1>
          <p className="text-slate-400 text-[10px] font-black tracking-[0.4em] uppercase mt-3">Sistem Terintegrasi v1.2</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase ml-4">Identifier</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-8 py-4.5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 focus:bg-white outline-none font-bold text-slate-800 transition-all disabled:opacity-50"
              placeholder="Username"
              disabled={isLoggingIn}
              autoComplete="username"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase ml-4">Security Key</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-8 py-4.5 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 focus:bg-white outline-none font-bold text-slate-800 transition-all disabled:opacity-50"
              placeholder="Password"
              disabled={isLoggingIn}
              autoComplete="current-password"
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 p-4 rounded-2xl text-[11px] font-bold border border-red-100 flex items-start animate-shake">
              <i className="fas fa-times-circle mr-3 mt-0.5 text-lg"></i>
              <div className="flex flex-col">
                 <span>{error}</span>
                 {error.includes("Timeout") && (
                   <span className="text-[9px] mt-1 opacity-80 italic font-medium leading-tight">Serverless backend memerlukan waktu sekitar 10-20 detik untuk inisialisasi awal. Silakan tunggu sebentar dan coba lagi.</span>
                 )}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoggingIn}
            className={`w-full bg-slate-900 hover:bg-blue-600 text-white font-black py-5 rounded-2xl shadow-2xl transition-all flex items-center justify-center space-x-3 active:scale-95 ${isLoggingIn ? 'opacity-50 cursor-wait' : ''}`}
          >
            {isLoggingIn ? (
              <>
                <i className="fas fa-circle-notch animate-spin"></i>
                <span>AUTHENTICATING...</span>
              </>
            ) : (
              <span>SIGN IN SYSTEM</span>
            )}
          </button>
        </form>

        <div className="mt-12 pt-8 border-t border-slate-100">
           <div className="flex items-center justify-between mb-4">
              <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Connectivity Status</span>
              {dbStatus === 'error' && (
                <button onClick={checkStatus} className="text-[9px] font-black text-blue-600 uppercase hover:underline">Retry Connection</button>
              )}
           </div>
           
           <div className={`p-5 rounded-2xl border-2 transition-all duration-500 ${
             dbStatus === 'warming' ? 'bg-amber-50 border-amber-100' : 
             dbStatus === 'connected' ? 'bg-emerald-50 border-emerald-100' : 
             'bg-red-50 border-red-100'
           }`}>
              <div className="flex items-center space-x-3">
                 <div className={`w-3 h-3 rounded-full ${
                   dbStatus === 'warming' ? 'bg-amber-500 animate-pulse' : 
                   dbStatus === 'connected' ? 'bg-emerald-500' : 
                   'bg-red-500'
                 }`}></div>
                 <span className={`text-[11px] font-black uppercase tracking-tight ${
                   dbStatus === 'warming' ? 'text-amber-700' : 
                   dbStatus === 'connected' ? 'text-emerald-700' : 
                   'text-red-700'
                 }`}>
                    {dbStatus === 'warming' ? 'INITIALIZING CLOUD...' : 
                     dbStatus === 'connected' ? 'DATABASE CONNECTED' : 
                     'DATABASE SYNC ERROR'}
                 </span>
              </div>
              <p className="mt-2 text-[10px] font-bold text-slate-500 italic opacity-80 leading-relaxed uppercase">
                {dbStatus === 'warming' ? 'Membangun koneksi ke infrastruktur cloud...' : 
                 dbStatus === 'connected' ? 'Koneksi PostgreSQL stabil. Data tersinkronisasi.' : 
                 'Gagal sinkronisasi otomatis. Anda tetap bisa mencoba login manual.'}
              </p>
           </div>
        </div>
      </div>
      <p className="mt-8 text-[10px] font-bold text-slate-600 uppercase tracking-widest opacity-50">Gunakan admin / admin123 untuk masuk</p>
    </div>
  );
};

export default AuthPage;
