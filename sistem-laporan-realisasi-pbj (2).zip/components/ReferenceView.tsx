import React, { useState, useEffect } from 'react';
import { ReferencePaket, Modul, User } from '../types';
import { MODUL_OPTIONS, STORAGE_KEYS } from '../constants';
import { getReferenceData, deleteReferenceItem, saveReferenceItem } from '../services/referenceService';
import ReferenceForm from './ReferenceForm';

const ReferenceView: React.FC = () => {
  const [activeModul, setActiveModul] = useState<Modul>('Swakelola');
  const [referenceList, setReferenceList] = useState<ReferencePaket[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ReferencePaket | undefined>(undefined);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    setReferenceList(getReferenceData());
    const savedAuth = localStorage.getItem(STORAGE_KEYS.AUTH);
    if (savedAuth) {
      setCurrentUser(JSON.parse(savedAuth));
    }
  }, []);

  const refreshList = () => {
    setReferenceList(getReferenceData());
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus item referensi ini dari basis data?')) {
      deleteReferenceItem(id);
      refreshList();
    }
  };

  const handleSave = (item: ReferencePaket) => {
    saveReferenceItem(item);
    refreshList();
    setIsFormOpen(false);
    setSelectedItem(undefined);
  };

  const filteredList = referenceList.filter(item => 
    item.modul === activeModul && (
      item.kodeRUP.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.namaPaket.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.satuanKerja.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const isAdmin = currentUser?.role === 'Admin';

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-12 animate-fade-in">
      {/* Search & Modul Selector & Add Button */}
      <div className="bg-white rounded-[3rem] shadow-sm border border-slate-100 p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-8 animate-fade-in">
        <div className="flex bg-slate-100 p-1.5 rounded-[1.25rem] w-fit shadow-inner">
          {MODUL_OPTIONS.map(m => (
            <button
              key={m}
              onClick={() => setActiveModul(m)}
              className={`px-8 py-3 rounded-2xl text-[13px] font-black transition-all ${activeModul === m ? 'bg-white text-blue-600 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {m}
            </button>
          ))}
        </div>
        
        <div className="flex flex-1 items-center gap-6">
          <div className="relative flex-1">
            <i className="fas fa-search absolute left-6 top-1/2 -translate-y-1/2 text-slate-300"></i>
            <input 
              type="text" 
              placeholder="Cari RUP, Paket, atau Satker..."
              className="w-full pl-14 pr-8 py-4.5 bg-slate-50/50 border-2 border-slate-100 rounded-2xl outline-none focus:border-blue-500 focus:bg-white transition-all text-sm font-bold shadow-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          {isAdmin && (
            <button 
              onClick={() => { setSelectedItem(undefined); setIsFormOpen(true); }}
              className="bg-slate-900 hover:bg-blue-600 text-white px-8 py-4.5 rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-2xl shadow-slate-200 transition-all active:scale-95 flex items-center space-x-3 whitespace-nowrap"
            >
              <i className="fas fa-plus"></i>
              <span>Tambah Referensi</span>
            </button>
          )}
        </div>
      </div>

      {/* List Card */}
      <div className="bg-white rounded-[3.5rem] shadow-[0_40px_100px_rgba(0,0,0,0.06)] border border-slate-100 overflow-hidden animate-fade-in">
        <div className="overflow-x-auto scrollbar-none">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50/70 border-b border-slate-100">
              <tr>
                <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Identitas RUP</th>
                <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Satuan Kerja</th>
                <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Objek Pekerjaan</th>
                <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Metode / Jenis</th>
                <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest">Pagu Anggaran</th>
                {isAdmin && <th className="px-10 py-7 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredList.length > 0 ? filteredList.map(item => (
                <tr key={item.id} className="text-sm hover:bg-blue-50/30 transition-all group">
                  <td className="px-10 py-8">
                    <span className="font-mono font-black text-blue-600 bg-blue-50 px-3 py-1.5 rounded-xl border border-blue-100">#{item.kodeRUP}</span>
                  </td>
                  <td className="px-10 py-8 text-slate-400 font-black uppercase text-[10px] tracking-tighter max-w-[150px] truncate">{item.satuanKerja}</td>
                  <td className="px-10 py-8 max-w-sm">
                    <div className="font-black text-slate-800 line-clamp-2 leading-tight tracking-tight group-hover:text-blue-700 transition-colors">{item.namaPaket}</div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex flex-col gap-2">
                      <span className="bg-slate-100 px-3 py-1.5 rounded-xl w-fit text-[9px] font-black uppercase tracking-widest border border-slate-200">{item.metodePengadaan}</span>
                      <span className="text-slate-400 italic text-[10px] font-bold">{item.jenisPengadaan}</span>
                    </div>
                  </td>
                  <td className="px-10 py-8">
                    <div className="flex flex-col gap-1.5">
                      <span className="font-black text-emerald-600 uppercase text-[9px] tracking-widest">{item.sumberDana}</span>
                      <span className="font-black text-slate-900 text-base tracking-tighter">Rp {item.pagu.toLocaleString('id-ID')}</span>
                    </div>
                  </td>
                  {isAdmin && (
                    <td className="px-10 py-8 text-right">
                      <div className="flex items-center justify-end space-x-3 opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
                        <button 
                          onClick={() => { setSelectedItem(item); setIsFormOpen(true); }}
                          className="w-10 h-10 flex items-center justify-center text-blue-600 bg-white border border-slate-100 hover:bg-blue-600 hover:text-white rounded-xl transition-all shadow-md active:scale-90"
                          title="Sunting Referensi"
                        >
                          <i className="fas fa-edit"></i>
                        </button>
                        <button 
                          onClick={() => handleDelete(item.id)}
                          className="w-10 h-10 flex items-center justify-center text-red-600 bg-white border border-slate-100 hover:bg-red-600 hover:text-white rounded-xl transition-all shadow-md active:scale-90"
                          title="Hapus Referensi"
                        >
                          <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              )) : (
                <tr>
                  <td colSpan={isAdmin ? 6 : 5} className="px-10 py-32 text-center">
                    <div className="flex flex-col items-center opacity-30 animate-fade-in">
                      <div className="w-24 h-24 bg-slate-50 rounded-[2rem] flex items-center justify-center mb-6">
                         <i className="fas fa-database text-5xl"></i>
                      </div>
                      <p className="text-sm font-black uppercase tracking-widest">Basis Data Kosong</p>
                      <p className="text-xs font-bold mt-2">Tidak ditemukan data referensi yang cocok.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-[2.5rem] p-10 flex items-start space-x-8 shadow-2xl shadow-blue-200 animate-fade-in overflow-hidden relative">
        <div className="w-16 h-16 rounded-3xl bg-white/20 flex items-center justify-center text-white text-3xl flex-shrink-0 relative z-10 backdrop-blur-md">
          <i className="fas fa-lightbulb"></i>
        </div>
        <div className="relative z-10">
          <h4 className="font-black text-white text-xl uppercase tracking-tight mb-2">Panduan Basis Data</h4>
          <p className="text-blue-50 text-[13px] leading-relaxed font-bold max-w-4xl">
            Data di atas adalah referensi master RUP 2026 yang diintegrasikan ke formulir pelaporan. {isAdmin ? 'Anda memiliki otoritas penuh untuk menambah, mengubah, atau menghapus entri master ini guna memastikan akurasi data.' : 'Jika terdapat ketidaksesuaian data, silakan berikan masukan kepada Administrator Bidang untuk pembaruan basis data.'}
          </p>
        </div>
        <div className="absolute right-[-5%] top-[-20%] w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
      </div>

      {isFormOpen && (
        <ReferenceForm 
          isOpen={isFormOpen}
          onClose={() => setIsFormOpen(false)}
          onSave={handleSave}
          initialData={selectedItem}
          activeModul={activeModul}
        />
      )}
    </div>
  );
};

export default ReferenceView;