
import React, { useState } from 'react';
import { Paket, User, Bidang } from '../types';
import { BIDANG_OPTIONS } from '../constants';
import { findByRUP } from '../services/referenceService';

interface PaketFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Paket>) => void;
  initialData?: Paket;
  user: User;
}

const PaketForm: React.FC<PaketFormProps> = ({ onClose, onSave, initialData, user }) => {
  const [formData, setFormData] = useState<Partial<Paket>>(initialData || {
    bidang: user.bidang !== 'ALL' ? user.bidang : 'BUN',
    kodeRUP: '',
    namaPaket: '',
    satuanKerja: '',
    metodePengadaan: '',
    jenisPengadaan: '',
    sumberDana: '',
    pagu: 0,
    hps: 0,
    nomorKontrak: '',
    nilaiKontrak: 0,
    realisasiKeuangan: 0,
    fisikRencana: 0,
    fisikRealisasi: 0,
    sp2d: ''
  });

  const [lookupError, setLookupError] = useState('');
  const [isAutoFilled, setIsAutoFilled] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    const val = type === 'number' ? parseFloat(value) || 0 : value;
    setFormData(prev => ({ ...prev, [name]: val }));
    if (name === 'kodeRUP') {
      setLookupError('');
      setIsAutoFilled(false);
    }
  };

  const handleLookup = () => {
    if (!formData.kodeRUP) {
      setLookupError('Masukkan Kode RUP terlebih dahulu');
      return;
    }
    // Search in reference database for the current module
    const result = findByRUP(formData.kodeRUP);
    if (result) {
      setFormData(prev => ({
        ...prev,
        namaPaket: result.namaPaket,
        pagu: result.pagu,
        satuanKerja: result.satuanKerja,
        metodePengadaan: result.metodePengadaan,
        jenisPengadaan: result.jenisPengadaan,
        sumberDana: result.sumberDana,
        // Optional: Pre-fill HPS with Pagu if empty
        hps: prev.hps === 0 ? result.pagu : prev.hps
      }));
      setLookupError('');
      setIsAutoFilled(true);
      setTimeout(() => setIsAutoFilled(false), 2000); // Visual cue
    } else {
      setLookupError('Kode RUP tidak ditemukan di database referensi');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.kodeRUP || !formData.namaPaket) {
      alert('Kode RUP dan Nama Paket wajib diisi');
      return;
    }
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-5xl max-h-[95vh] rounded-3xl shadow-2xl flex flex-col overflow-hidden transform transition-all animate-slide-up">
        <div className="p-8 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-2xl font-black text-slate-800 tracking-tight">
              {initialData ? 'Update Data Realisasi' : 'Tambah Paket Baru'}
            </h3>
            <p className="text-sm text-slate-500 mt-1">Lengkapi data realisasi fisik dan keuangan untuk monitoring berkala.</p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-slate-200 rounded-full transition-all active:scale-90">
            <i className="fas fa-times text-slate-500 text-xl"></i>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-8 lg:p-12">
          <div className="space-y-10">
            {/* Automatic Data Area */}
            <div className={`p-8 rounded-2xl border-2 transition-all duration-500 ${isAutoFilled ? 'bg-emerald-50 border-emerald-200 ring-4 ring-emerald-100' : 'bg-blue-50/50 border-blue-100'}`}>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
                  <i className="fas fa-magic"></i>
                </div>
                <h4 className="font-bold text-blue-900">Otomatisasi Data (RUP Lookup)</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="relative">
                  <label className="block text-xs font-bold text-blue-900/60 uppercase mb-2">Kode RUP</label>
                  <div className="flex group">
                    <input 
                      type="text" 
                      name="kodeRUP" 
                      value={formData.kodeRUP} 
                      onChange={handleChange}
                      className={`flex-1 p-3 border-2 rounded-l-xl outline-none transition-all font-mono font-bold ${lookupError ? 'border-red-300' : 'border-blue-200 focus:border-blue-500'}`}
                      placeholder="Contoh: 39531761"
                      required
                    />
                    <button 
                      type="button"
                      onClick={handleLookup}
                      className="bg-blue-600 text-white px-5 rounded-r-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200 flex items-center justify-center group-active:scale-95"
                      title="Klik untuk mencari data paket otomatis"
                    >
                      <i className="fas fa-search"></i>
                    </button>
                  </div>
                  {lookupError && <p className="absolute -bottom-5 left-0 text-[10px] text-red-500 font-bold animate-pulse">{lookupError}</p>}
                </div>

                <div className="md:col-span-1">
                  <label className="block text-xs font-bold text-blue-900/60 uppercase mb-2">Satuan Kerja</label>
                  <input 
                    type="text" 
                    name="satuanKerja" 
                    value={formData.satuanKerja} 
                    onChange={handleChange}
                    placeholder="Auto-fill..."
                    className="w-full p-3 bg-white/80 border-2 border-blue-100 rounded-xl outline-none focus:border-blue-500 transition-all text-sm font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-blue-900/60 uppercase mb-2">Bidang Pelapor</label>
                  <select 
                    name="bidang" 
                    value={formData.bidang} 
                    onChange={handleChange}
                    className="w-full p-3 bg-white/80 border-2 border-blue-100 rounded-xl outline-none focus:border-blue-500 transition-all font-bold text-blue-800"
                    disabled={user.role !== 'Admin'}
                  >
                    {BIDANG_OPTIONS.map(b => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-xs font-bold text-blue-900/60 uppercase mb-2">Nama Paket Pekerjaan</label>
                <textarea 
                  name="namaPaket" 
                  value={formData.namaPaket} 
                  onChange={handleChange}
                  rows={2}
                  className="w-full p-4 bg-white/80 border-2 border-blue-100 rounded-xl outline-none focus:border-blue-500 transition-all text-sm font-bold"
                  placeholder="Nama paket akan terisi otomatis setelah memasukkan RUP..."
                  required
                ></textarea>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Specification */}
              <div className="space-y-6">
                <h4 className="font-black text-slate-800 border-l-4 border-blue-500 pl-4 text-lg">Detail Pengadaan</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Metode</label>
                    <input type="text" name="metodePengadaan" value={formData.metodePengadaan} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none text-sm transition-all" />
                  </div>
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Jenis</label>
                    <input type="text" name="jenisPengadaan" value={formData.jenisPengadaan} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none text-sm transition-all" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Sumber Dana</label>
                    <input type="text" name="sumberDana" value={formData.sumberDana} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none text-sm font-bold text-emerald-600 transition-all" />
                  </div>
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nomor SP2D</label>
                    <input type="text" name="sp2d" value={formData.sp2d} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none text-sm transition-all" placeholder="Jika ada..." />
                  </div>
                </div>
              </div>

              {/* Finance & Progress */}
              <div className="space-y-6">
                <h4 className="font-black text-slate-800 border-l-4 border-emerald-500 pl-4 text-lg">Anggaran & Progres</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Pagu (Rp)</label>
                    <input type="number" name="pagu" value={formData.pagu} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none font-mono font-bold text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">HPS (Rp)</label>
                    <input type="number" name="hps" value={formData.hps} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none font-mono text-sm" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">No. Kontrak</label>
                    <input type="text" name="nomorKontrak" value={formData.nomorKontrak} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none text-sm" />
                  </div>
                  <div className="col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nilai Kontrak (Rp)</label>
                    <input type="number" name="nilaiKontrak" value={formData.nilaiKontrak} onChange={handleChange} className="w-full p-3 border-2 border-slate-100 rounded-xl focus:border-blue-500 outline-none font-mono font-bold text-sm" />
                  </div>
                </div>
                <div className="p-5 bg-emerald-50 border-2 border-emerald-100 rounded-2xl">
                  <label className="block text-sm font-black text-emerald-800 mb-2 uppercase tracking-tight flex items-center">
                    <i className="fas fa-hand-holding-usd mr-2"></i>
                    Realisasi Keuangan
                  </label>
                  <input 
                    type="number" 
                    name="realisasiKeuangan" 
                    value={formData.realisasiKeuangan} 
                    onChange={handleChange}
                    className="w-full p-4 bg-white border-2 border-emerald-200 rounded-xl outline-none focus:ring-4 focus:ring-emerald-100 font-mono font-black text-xl text-emerald-600 text-center"
                    placeholder="0"
                  />
                  <div className="flex justify-between mt-3 px-2">
                     <span className="text-[10px] font-bold text-emerald-500">Sisa Kontrak:</span>
                     <span className="text-[10px] font-bold text-emerald-700">Rp {((formData.pagu || 0) - (formData.realisasiKeuangan || 0)).toLocaleString('id-ID')}</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6 pt-2">
                  <div className="relative">
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2">Fisik Rencana (%)</label>
                    <input type="number" name="fisikRencana" value={formData.fisikRencana} onChange={handleChange} max="100" step="0.01" className="w-full p-3 border-2 border-slate-100 rounded-xl outline-none focus:border-blue-500 transition-all font-bold text-center" />
                  </div>
                  <div className="relative">
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2">Fisik Realisasi (%)</label>
                    <input type="number" name="fisikRealisasi" value={formData.fisikRealisasi} onChange={handleChange} max="100" step="0.01" className="w-full p-3 border-2 border-blue-200 rounded-xl outline-none focus:border-blue-500 transition-all font-bold text-center text-blue-700" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 flex items-center justify-between pt-10 border-t border-slate-100">
             <div className="hidden md:flex items-center space-x-2 text-slate-400 text-xs">
                <i className="fas fa-shield-alt text-emerald-400"></i>
                <span>Data dienkripsi dan dicatat dalam Audit Log secara otomatis.</span>
             </div>
             <div className="flex space-x-4 w-full md:w-auto">
                <button 
                  type="button" 
                  onClick={onClose}
                  className="flex-1 md:flex-none px-10 py-4 border-2 border-slate-100 rounded-2xl text-slate-500 font-black hover:bg-slate-50 transition-all active:scale-95"
                >
                  Batal
                </button>
                <button 
                  type="submit"
                  className="flex-1 md:flex-none px-12 py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 shadow-2xl shadow-slate-200 transition-all active:scale-95 flex items-center justify-center space-x-2"
                >
                  <i className="fas fa-save"></i>
                  <span>Simpan Realisasi</span>
                </button>
             </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PaketForm;
