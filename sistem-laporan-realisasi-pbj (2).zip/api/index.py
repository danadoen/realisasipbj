
import os
import sys
import psycopg2
from psycopg2.extras import RealDictCursor
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import datetime
import uuid
import time
from contextlib import contextmanager
from typing import List, Optional

# --- DATABASE CONFIG ---
DATABASE_URL = "postgresql://postgres:realisasipbj2026@db.ziyfssoaxjnjjnfsudkp.supabase.co:5432/postgres?sslmode=require"

# Global flag to track if DB has been initialized
_db_initialized = False

def log_err(message):
    print(f"[ERROR] {message}", file=sys.stderr)

@contextmanager
def get_db_conn():
    conn = None
    try:
        # Timeout 5s agar tidak memicu timeout Vercel yang lebih ketat
        conn = psycopg2.connect(DATABASE_URL, connect_timeout=5)
        conn.autocommit = True
        yield conn
    except Exception as e:
        log_err(f"Koneksi Database Gagal: {str(e)}")
        raise e
    finally:
        if conn:
            conn.close()

def run_init_db():
    global _db_initialized
    if _db_initialized:
        return
        
    try:
        with get_db_conn() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    role TEXT NOT NULL,
                    bidang TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS pakets (
                    id TEXT PRIMARY KEY,
                    modul TEXT NOT NULL,
                    bidang TEXT NOT NULL,
                    kode_rup TEXT,
                    nama_paket TEXT,
                    satuan_kerja TEXT,
                    metode_pengadaan TEXT,
                    jenis_pengadaan TEXT,
                    sumber_dana TEXT,
                    pagu NUMERIC DEFAULT 0,
                    hps NUMERIC DEFAULT 0,
                    nomor_kontrak TEXT,
                    nilai_kontrak NUMERIC DEFAULT 0,
                    realisasi_keuangan NUMERIC DEFAULT 0,
                    fisik_rencana NUMERIC DEFAULT 0,
                    fisik_realisasi NUMERIC DEFAULT 0,
                    sp2d TEXT,
                    updated_by TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id TEXT PRIMARY KEY,
                    user_id TEXT,
                    username TEXT,
                    action TEXT,
                    paket_id TEXT,
                    paket_name TEXT,
                    details TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
            """)
            
            cur.execute("SELECT id FROM users WHERE username = 'admin' LIMIT 1")
            if not cur.fetchone():
                cur.execute("INSERT INTO users (id, username, password, role, bidang) VALUES (%s, %s, %s, %s, %s)",
                            (str(uuid.uuid4()), 'admin', 'admin123', 'Admin', 'ALL'))
            cur.close()
            _db_initialized = True
    except Exception as e:
        log_err(f"Inisialisasi Tabel Gagal: {str(e)}")

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
async def health():
    try:
        run_init_db()
        with get_db_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT 1")
            cur.close()
        return {"status": "online", "db": "connected"}
    except Exception as e:
        return {"status": "error", "db": "disconnected", "detail": str(e)}

class LoginRequest(BaseModel):
    username: str
    password: str

@app.post("/api/login")
async def login(req: LoginRequest):
    try:
        run_init_db()
        with get_db_conn() as conn:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("SELECT id, username, password, role, bidang FROM users WHERE username = %s LIMIT 1", (req.username,))
            user = cur.fetchone()
            cur.close()
            
            if not user:
                raise HTTPException(status_code=401, detail="User tidak ditemukan")
                
            if user['password'] != req.password:
                raise HTTPException(status_code=401, detail="Password salah")
                
            user_data = dict(user)
            if 'password' in user_data:
                del user_data['password']
            return user_data
    except Exception as e:
        if isinstance(e, HTTPException): raise e
        raise HTTPException(status_code=500, detail=f"Database connectivity issue: {str(e)}")

@app.get("/api/users")
async def get_users():
    try:
        with get_db_conn() as conn:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("SELECT id, username, role, bidang FROM users ORDER BY username ASC")
            rows = cur.fetchall()
            cur.close()
            return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/users")
async def save_user(user: dict):
    try:
        with get_db_conn() as conn:
            cur = conn.cursor()
            u_id = user.get('id') or str(uuid.uuid4())
            cur.execute("""
                INSERT INTO users (id, username, password, role, bidang)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET 
                username=EXCLUDED.username, password=EXCLUDED.password, 
                role=EXCLUDED.role, bidang=EXCLUDED.bidang
            """, (u_id, user.get('username'), user.get('password'), user.get('role'), user.get('bidang')))
            cur.close()
            return {"status": "success", "id": u_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/users/{user_id}")
async def delete_user(user_id: str):
    try:
        with get_db_conn() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM users WHERE id = %s", (user_id,))
            cur.close()
            return {"status": "deleted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/pakets")
async def get_pakets():
    try:
        with get_db_conn() as conn:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("SELECT * FROM pakets ORDER BY updated_at DESC")
            rows = cur.fetchall()
            cur.close()
            return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/pakets")
async def save_paket(paket: dict):
    try:
        with get_db_conn() as conn:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            p_id = paket.get('id') or str(uuid.uuid4())
            cur.execute("""
                INSERT INTO pakets (
                    id, modul, bidang, kode_rup, nama_paket, satuan_kerja, metode_pengadaan,
                    jenis_pengadaan, sumber_dana, pagu, hps, nomor_kontrak, nilai_kontrak,
                    realisasi_keuangan, fisik_rencana, fisik_realisasi, sp2d, updated_by, updated_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                ON CONFLICT (id) DO UPDATE SET 
                    bidang=EXCLUDED.bidang, 
                    nama_paket=EXCLUDED.nama_paket,
                    satuan_kerja=EXCLUDED.satuan_kerja,
                    pagu=EXCLUDED.pagu, 
                    hps=EXCLUDED.hps,
                    nomor_kontrak=EXCLUDED.nomor_kontrak,
                    nilai_kontrak=EXCLUDED.nilai_kontrak,
                    realisasi_keuangan=EXCLUDED.realisasi_keuangan,
                    fisik_rencana=EXCLUDED.fisik_rencana,
                    fisik_realisasi=EXCLUDED.fisik_realisasi,
                    sp2d=EXCLUDED.sp2d,
                    updated_by=EXCLUDED.updated_by,
                    updated_at=CURRENT_TIMESTAMP
            """, (
                p_id, paket.get('modul'), paket.get('bidang'), paket.get('kodeRUP'), 
                paket.get('namaPaket'), paket.get('satuanKerja'), paket.get('metodePengadaan'),
                paket.get('jenisPengadaan'), paket.get('sumberDana'), paket.get('pagu', 0), 
                paket.get('hps', 0), paket.get('nomorKontrak'), paket.get('nilaiKontrak', 0), 
                paket.get('realisasiKeuangan', 0), paket.get('fisikRencana', 0), 
                paket.get('fisikRealisasi', 0), paket.get('sp2d'), paket.get('updatedBy')
            ))
            cur.execute("SELECT * FROM pakets WHERE id = %s", (p_id,))
            row = cur.fetchone()
            cur.close()
            return row
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/api/pakets/{paket_id}")
async def delete_paket(paket_id: str):
    try:
        with get_db_conn() as conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM pakets WHERE id = %s", (paket_id,))
            cur.close()
            return {"status": "deleted", "id": paket_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/logs")
async def get_logs():
    try:
        with get_db_conn() as conn:
            cur = conn.cursor(cursor_factory=RealDictCursor)
            cur.execute("""
                SELECT id, timestamp, user_id as "userId", username, action, 
                       paket_id as "paketId", paket_name as "paketName", details 
                FROM audit_logs ORDER BY timestamp DESC LIMIT 100
            """)
            rows = cur.fetchall()
            cur.close()
            return rows
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/logs")
async def add_log(log: dict):
    try:
        with get_db_conn() as conn:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO audit_logs (id, user_id, username, action, paket_id, paket_name, details)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (str(uuid.uuid4()), log.get('userId'), log.get('username'), log.get('action'), 
                  log.get('paketId'), log.get('paketName'), log.get('details')))
            cur.close()
            return {"status": "logged"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
