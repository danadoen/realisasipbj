
import { Bidang, Modul } from './types';

export const BIDANG_OPTIONS: Bidang[] = [
  'BUN',
  'BITNAKES',
  'UMUM',
  'PROGRAM',
  'KEUANGAN',
  'UPTPPAT',
  'PSP',
  'TPH/LUH'
];
export const MODUL_OPTIONS: Modul[] = ['Penyedia', 'Swakelola'];

export const STORAGE_KEYS = {
  PAKETS: 'pbj_pakets_v1',
  AUDIT_LOGS: 'pbj_audit_logs_v1',
  AUTH: 'pbj_auth_session',
  USERS: 'pbj_users_v1',
  REFERENCE: 'pbj_reference_v1'
};
